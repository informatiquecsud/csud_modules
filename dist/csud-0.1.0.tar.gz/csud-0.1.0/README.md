# csud_modules

Modules Python used at Collège du Sud for teaching CS

## Loading a module from Pyodide (WebTigerPython)

```python
import micropip
await micropip.install("csud_modules")
```

